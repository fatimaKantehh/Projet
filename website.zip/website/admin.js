document.addEventListener('DOMContentLoaded', function () {
    const userModal = document.getElementById('userModal');
    const userForm = document.getElementById('userForm');
    const addUserButton = document.getElementById('addUserButton');
    const closeBtn = userModal.querySelector('.close');
    const userTable = document.getElementById('userTable').querySelector('tbody');

    let users = [
        { id: 1, email: 'admin@example.com', role: 'admin' },
        { id: 2, email: 'editor@example.com', role: 'editor' },
    ];

    function openModal() {
        userForm.reset();
        userModal.style.display = 'block';
    }

    function closeModal() {
        userModal.style.display = 'none';
    }

    function renderUsers() {
        userTable.innerHTML = '';
        users.forEach(user => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${user.id}</td>
                <td>${user.email}</td>
                <td>${user.role}</td>
                <td>
                    <button class="editUser" data-id="${user.id}">Modifier</button>
                    <button class="deleteUser" data-id="${user.id}">Supprimer</button>
                </td>
            `;
            userTable.appendChild(row);
        });
    }

    userForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const email = document.getElementById('userEmail').value;
        const role = document.getElementById('userRole').value;
        const id = users.length ? users[users.length - 1].id + 1 : 1;
        users.push({ id, email, role });
        renderUsers();
        closeModal();
    });

    addUserButton.addEventListener('click', openModal);
    closeBtn.addEventListener('click', closeModal);

    window.addEventListener('click', function (event) {
        if (event.target === userModal) {
            closeModal();
        }
    });

    userTable.addEventListener('click', function (event) {
        if (event.target.classList.contains('editUser')) {
            const userId = event.target.getAttribute('data-id');
            const user = users.find(user => user.id == userId);
            document.getElementById('userEmail').value = user.email;
            document.getElementById('userRole').value = user.role;
            openModal();
        }

        if (event.target.classList.contains('deleteUser')) {
            const userId = event.target.getAttribute('data-id');
            users = users.filter(user => user.id != userId);
            renderUsers();
        }
    });

    renderUsers();
});
