document.addEventListener("DOMContentLoaded", function () {
    const modal = document.getElementById("modal");
    const modalImg = modal.querySelector(".modal-img");
    const modalDescription = modal.querySelector(".modal-description");
    const closeBtn = modal.querySelector(".close");

    // Fonction pour ouvrir le modal lors du clic sur le bouton "View"
    function openModal(imgSrc, description) {
        modalImg.src = imgSrc;
        modalDescription.textContent = description;
        modal.style.display = "flex"; // Affiche le modal en utilisant flexbox
    }

    // Ajouter un écouteur d'événement pour chaque bouton "View"
    document.querySelectorAll(".view-btn").forEach(function (button) {
        button.addEventListener("click", function () {
            const post = button.closest('.post');
            const img = post.querySelector("img");
            const imgSrc = img.src;
            const description = img.dataset.description;
            
            openModal(imgSrc, description); // Appeler la fonction pour ouvrir le modal
        });
    });

    // Fermer le modal lors du clic sur le bouton de fermeture
    closeBtn.addEventListener("click", function () {
        modal.style.display = "none"; // Cacher le modal lorsqu'on clique sur la croix
    });

    // Fermer le modal lorsqu'on clique en dehors de celui-ci
    window.addEventListener("click", function (event) {
        if (event.target === modal) {
            modal.style.display = "none"; // Cacher le modal lorsqu'on clique à l'extérieur
        }
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const modal = document.getElementById("modal");
    const modalImg = document.querySelector(".modal-img");
    const modalDescription = document.querySelector(".modal-description");
    const closeBtn = document.querySelector(".close");
    const posts = document.querySelectorAll(".post");

    document.querySelectorAll(".view-btn").forEach(function (button) {
        button.addEventListener("click", function () {
            const post = button.closest('.post');
            const img = post.querySelector("img");

            modalImg.src = img.src;
            modalDescription.textContent = img.dataset.description;

            modal.style.display = "block";
        });
    });

    closeBtn.addEventListener("click", function () {
        modal.style.display = "none";
    });

    window.addEventListener("click", function (event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    });

    // Filter posts based on category
    const menuItems = document.querySelectorAll("#menu li");
    menuItems.forEach(item => {
        item.addEventListener("click", function () {
            const filter = this.getAttribute("data-filter");

            menuItems.forEach(i => i.classList.remove("active"));
            this.classList.add("active");

            posts.forEach(post => {
                if (filter === "all" || post.classList.contains(filter)) {
                    post.style.display = "flex";
                } else {
                    post.style.display = "none";
                }
            });
        });
    });
});



document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('myModal'); // Récupère le modal par son id

    // Récupère les liens de connexion et d'inscription par leur id
    const loginLink = document.getElementById('loginLink');
    const signupLink = document.getElementById('signupLink');

    // Récupère le bouton de fermeture du modal
    const closeBtn = document.getElementsByClassName('close')[0];

    // Récupère les éléments de contrôle pour les onglets de connexion et d'inscription
    const loginRadio = document.getElementById('login');
    const signupRadio = document.getElementById('signup');

    // Récupère les formulaires
    const loginForm = document.querySelector('.form-inner form.login');
    const signupForm = document.querySelector('.form-inner form.signup');

    // Fonction pour afficher le modal avec le formulaire de connexion
    function showLoginForm() {
        modal.style.display = 'block'; // Affiche le modal
        loginRadio.checked = true; // Sélectionne l'option de connexion
        loginForm.classList.remove('hidden'); // Affiche le formulaire de connexion
        signupForm.classList.add('hidden'); // Masque le formulaire d'inscription
    }

    // Fonction pour afficher le modal avec le formulaire d'inscription
    function showSignupForm() {
        modal.style.display = 'block'; // Affiche le modal
        signupRadio.checked = true; // Sélectionne l'option d'inscription
        signupForm.classList.remove('hidden'); // Affiche le formulaire d'inscription
        loginForm.classList.add('hidden'); // Masque le formulaire de connexion
    }

    // Ajoute un écouteur d'événement au clic sur le lien de connexion
    loginLink.addEventListener('click', function (e) {
        e.preventDefault(); // Empêche le lien de suivre son comportement par défaut
        showLoginForm();
    });

    // Ajoute un écouteur d'événement au clic sur le lien d'inscription
    signupLink.addEventListener('click', function (e) {
        e.preventDefault(); // Empêche le lien de suivre son comportement par défaut
        showSignupForm();
    });

    // Ajoute un écouteur d'événement pour fermer le modal en cliquant sur le bouton de fermeture
    closeBtn.addEventListener('click', function () {
        modal.style.display = 'none'; // Cache le modal
    });

    // Ajoute un écouteur d'événement pour fermer le modal en cliquant sur n'importe quelle partie en dehors du contenu
    window.addEventListener('click', function (e) {
        if (e.target === modal) {
            modal.style.display = 'none'; // Cache le modal
        }
    });

    // Bascule entre les formulaires de connexion et d'inscription en cliquant sur les labels
    document.querySelector('.slide.login').addEventListener('click', showLoginForm);
    document.querySelector('.slide.signup').addEventListener('click', showSignupForm);
});


document.addEventListener("DOMContentLoaded", function() {
    const modal = document.getElementById("myModal");
    const modalImg = document.querySelector(".modal-img");
    const modalDescription = document.querySelector(".modal-description");
    const closeBtn = document.querySelector(".close");

    // Gestion de l'ouverture du modal au clic sur le bouton "Éditer"
    document.getElementById("editButton").addEventListener("click", function() {
        modal.style.display = "block";
    });

    // Gestion de la fermeture du modal
    closeBtn.addEventListener("click", function() {
        modal.style.display = "none";
    });

    // Fermer le modal si l'utilisateur clique en dehors de celui-ci
    window.addEventListener("click", function(event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    });

    // Soumission du formulaire de connexion
    document.getElementById("loginForm").addEventListener("submit", function(event) {
        event.preventDefault(); // Empêche le formulaire de se soumettre normalement
        
        // Récupère les valeurs des champs email et password
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;
        
        // Vérifie les identifiants (simulé ici)
        if (email === "oulimatasene@esp.sn" && password === "azerty") {
            // Redirige vers edit.html (chemin relatif)
            window.location.href = "edit.html";
        } else {
            // Affiche un message d'erreur (facultatif)
            alert("Invalid credentials. Please try again.");
        }
    });

    // Gestion de l'affichage de l'image et description dans le modal
    document.querySelectorAll(".view-btn").forEach(function(button) {
        button.addEventListener("click", function() {
            const post = button.closest('.post');
            const img = post.querySelector("img");
            
            modalImg.src = img.src;
            modalDescription.textContent = img.alt; // Utilisation de alt au lieu de dataset.description
            
            modal.style.display = "block";
        });
    });
});


